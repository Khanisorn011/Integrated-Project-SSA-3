describe(`TC-FE-PBI1-VIEW-SALE-ITEM-GALLERY-1\n 
    Test Scenario : normal - sale item table is empty`, () => {

    let resource = '/sale-items'
    let baseAPI = Cypress.config('baseAPI')

    beforeEach(()=> {
        cy.visit(resource) ;
        cy.wait(100) ;
    }) ;

    it(`Open the sale item gallery page at ${resource}`, () => {
    })

    it('The sale item table shoud be empty and the page show "no sale item".',()=>{
        cy.intercept('GET',`${baseAPI}/v1/**`,{
            statusCode: 200,
            data: []
        }).as('request')

        cy.visit(resource)

        cy.wait('@request').then((interception)=>{
            const response = interception.response
            expect(response.statusCode).to.equal(200)
        })

        cy.get('itbms-row').should('have.length',0)
        cy.contains(/no sale item/i)
    })
})